<?php echo \Livewire\Livewire::scripts(); ?>

<?php echo \Livewire\Livewire::styles(); ?>

<?php echo $__env->yieldContent('content'); ?><?php /**PATH C:\wamp64\www\Xfortech\Laundry-web\resources\views/layouts/print-layout.blade.php ENDPATH**/ ?>