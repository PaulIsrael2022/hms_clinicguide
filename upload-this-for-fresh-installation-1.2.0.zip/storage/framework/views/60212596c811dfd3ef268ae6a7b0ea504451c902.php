<div>
    <div class="row align-items-center justify-content-between mb-4">
        <div class="col">
            <h5 class="fw-500 text-white"><?php echo e($lang->data['expense_category'] ?? 'Expense Category'); ?></h5>
        </div>
        <div class="col-auto">
            <a data-bs-toggle="modal" data-bs-target="#addcategory" wire:click="resetInputFields"
                class="btn btn-icon btn-3 btn-white text-primary mb-0">
                <i class="fa fa-plus me-2"></i> <?php echo e($lang->data['add_new_category'] ?? 'Add New Category'); ?>

            </a>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card mb-4">
                <div class="card-header p-4">
                    <div class="row">
                        <div class="col-md-12">
                            <input type="text" class="form-control"
                                placeholder="<?php echo e($lang->data['search_here'] ?? 'Search here'); ?>" wire:model="search">
                        </div>
                    </div>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table align-items-center mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th class="text-uppercase text-secondary text-xs opacity-7">#</th>
                                    <th class="text-uppercase text-secondary text-xs opacity-7 ps-2">
                                        <?php echo e($lang->data['expense_category'] ?? 'Expense Category'); ?></th>
                                    <th class="text-center text-uppercase text-secondary text-xs opacity-7">
                                        <?php echo e($lang->data['status'] ?? 'Status'); ?></th>
                                    <th class="text-uppercase text-secondary text-xs opacity-7 ps-2">
                                            <?php echo e($lang->data['created_by'] ?? 'Created By'); ?></th>
                                    <th class="text-secondary opacity-7"></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    
                                    $i = 1;
                                ?>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <p class="text-sm px-3 mb-0"><?php echo e($i++); ?> </p>
                                        </td>
                                        <td>
                                            <p class="text-sm font-weight-bold mb-0"><?php echo e($row->expense_category_name); ?>

                                            </p>
                                        </td>
                                        <td class="align-middle text-center">
                                            <a type="button"
                                                class="badge badge-sm bg-dark text-uppercase"><?php echo e(getExpenseCategoryType($row->expense_category_type)); ?></a>
                                        </td>
                                        <td>
                                            <p class="text-sm mb-0 text-uppercase">
                                                <?php echo e($row->user->name ?? ""); ?></p>
                                        </td>
                                        <td>
                                            <a data-bs-toggle="modal" wire:click="edit(<?php echo e($row->id); ?>)"
                                                data-bs-target="#editcategory" type="button"
                                                class="badge badge-xs badge-warning fw-600 text-xs">
                                                <?php echo e($lang->data['edit'] ?? 'Edit'); ?>

                                            </a>
                                            <a href="#" type="button" wire:click="delete(<?php echo e($row->id); ?>)"
                                                class="ms-2 badge badge-xs badge-danger text-xs fw-600">
                                                <?php echo e($lang->data['delete'] ?? 'Delete'); ?>

                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div wire:ignore.self class="modal fade" class="modal fade " id="addcategory" tabindex="-1" role="dialog"
        aria-labelledby="addcategory" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h6 class="modal-title fw-600">
                        <?php echo e($lang->data['add_Expense_category'] ?? 'Add Expense Category'); ?>

                    </h6>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form>
                    <div class="modal-body">
                        <div class="row g-3 align-items-center">
                            <div class="col-md-12">
                                <label class="form-label"><?php echo e($lang->data['category_name'] ?? 'Category Name'); ?>

                                    <span class="text-danger">*</span></label>
                                <input type="text" required class="form-control"
                                    placeholder="<?php echo e($lang->data['enter_category_name'] ?? 'Enter Category Name'); ?>"
                                    wire:model="expense_category_name">
                                <?php $__errorArgs = ['expense_category_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="error text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-12">
                                <label
                                    class="form-label"><?php echo e($lang->data['category_type'] ?? 'Category Type'); ?><span
                                        class="text-danger">*</span></label>
                                <select class="form-select" wire:model="expense_category_type"
                                    wire:change="changeCategoryType">
                                    <option class="select-box" value="">
                                        <?php echo e($lang->data['choose_expense_category'] ?? 'Choose Expense Category'); ?>

                                    </option>
                                    <option class="select-box" value="1"><?php echo e($lang->data['asset'] ?? 'Asset'); ?>

                                    </option>
                                    <option class="select-box" value="2">
                                        <?php echo e($lang->data['liability'] ?? 'Liability'); ?></option>
                                </select>
                                <?php $__errorArgs = ['expense_category_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="error text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary"
                            data-bs-dismiss="modal"><?php echo e($lang->data['cancel'] ?? 'Cancel'); ?></button>
                        <button type="submit" class="btn btn-primary"
                            wire:click.prevent="store()"><?php echo e($lang->data['save'] ?? 'Save'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div wire:ignore.self class="modal fade" class="modal fade " id="editcategory" tabindex="-1" role="dialog"
        aria-labelledby="editcategory" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h6 class="modal-title fw-600">
                        <?php echo e($lang->data['edit_expense_category'] ?? 'Edit Expense Category'); ?></h6>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form>
                    <div class="modal-body">
                        <div class="row g-3 align-items-center">
                            <div class="col-md-12">
                                <label class="form-label"><?php echo e($lang->data['category_name'] ?? 'Category Name'); ?>

                                    <span class="text-danger">*</span></label>
                                <input type="text" required class="form-control"
                                    placeholder="<?php echo e($lang->data['enter_category_name'] ?? 'Enter Category Name'); ?>"
                                    wire:model="expense_category_name">
                                <?php $__errorArgs = ['expense_category_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="error text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-12">
                                <label
                                    class="form-label"><?php echo e($lang->data['category_type'] ?? 'Category Type'); ?><span
                                        class="text-danger">*</span></label>
                                <select class="form-select" wire:model="expense_category_type"
                                    wire:change="changeCategoryType">
                                    <option class="select-box" value="">
                                        <?php echo e($lang->data['choose_expense_category'] ?? 'Choose Expense Category'); ?>

                                    </option>
                                    <option class="select-box" value="1"><?php echo e($lang->data['asset'] ?? 'Asset'); ?>

                                    </option>
                                    <option class="select-box" value="2">
                                        <?php echo e($lang->data['liability'] ?? 'Liability'); ?></option>
                                </select>
                                <?php $__errorArgs = ['expense_category_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="error text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary"
                            data-bs-dismiss="modal"><?php echo e($lang->data['cancel'] ?? 'Cancel'); ?></button>
                        <button type="submit" class="btn btn-primary"
                            wire:click.prevent="update()"><?php echo e($lang->data['save'] ?? 'Save'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\wamp64\www\Xfortech\Laundry-web\resources\views/livewire/admin/expense/expensecategories.blade.php ENDPATH**/ ?>