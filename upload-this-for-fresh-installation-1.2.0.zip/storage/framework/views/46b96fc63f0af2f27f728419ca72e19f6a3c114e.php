<div>
    <div class="row align-items-center justify-content-between mb-4">
        <div class="col">
            <h5 class="fw-500 text-white"><?php echo e($lang->data['translations']??'Translations'); ?></h5>
        </div>
        <div class="col-auto">
            <a href="<?php echo e(route('admin.add_translations')); ?>" class="btn btn-icon btn-3 btn-white text-primary mb-0">
                <i class="fa fa-plus me-2"></i> <?php echo e($lang->data['add_translations']??'Add New Translation'); ?>

            </a>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card mb-4">
                <div class="card-header p-4">
                    <div class="row">
                        <div class="col-md-12">
                            <input type="text" class="form-control" placeholder="<?php echo e($lang->data['search_here'] ?? 'Search Here'); ?>"
                                wire:model="search_query">
                        </div>
                    </div>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table align-items-center mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th class="text-uppercase text-secondary text-xs opacity-7"><?php echo e($lang->data['translation_name'] ?? 'Translation Name'); ?></th>
                                    <th class="text-uppercase text-secondary text-xs opacity-7 ps-2"><?php echo e($lang->data['status'] ?? 'Status'); ?></th>
                                    <th class="text-uppercase text-secondary text-xs  opacity-7"><?php echo e($lang->data['actions'] ?? 'Actions'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $translations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <p class="text-sm px-3 mb-0"><?php echo e($item->name); ?> </p>
                                        </td>
                                        <td>
                                            <p class="text-sm  mb-0">
                                                <?php if($item->is_active): ?>
                                                    <span class="badge badge-success"><?php echo e($lang->data['active'] ?? 'Active'); ?></span>
                                                <?php endif; ?>
                                                <?php if($item->default): ?>
                                                    <span class="badge badge-primary"><?php echo e($lang->data['default'] ?? 'Default'); ?></span>
                                                <?php endif; ?>
                                                <?php if($item->is_rtl): ?>
                                                    <span class="badge badge-secondary"><?php echo e($lang->data['rtl'] ?? 'RTL'); ?></span>
                                                <?php endif; ?>
                                            </p>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('admin.edit_translations', $item->id)); ?>" type="button"
                                                class="badge badge-xs badge-warning fw-600 text-xs">
                                                <?php echo e($lang->data['edit'] ?? 'Edit'); ?>

                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\wamp64\www\Xfortech\Laundry-web\resources\views/livewire/admin/translations/translations.blade.php ENDPATH**/ ?>