<div>
    <div class="row align-items-center justify-content-between mb-4">
        <div class="col">
            <h5 class="fw-500 text-white"><?php echo e($lang->data['sms_settings'] ?? 'SMS Settings'); ?></h5>
        </div>
    </div>
    <div class="row" x-data="initz()" x-init="start()">
        <div class="col-12">
            <div class="card">
                <div class="card-body p-3">
                    <form class="row g-3 align-items-center">
                        <div><span
                                class="text-sm text-uppercase"><?php echo e($lang->data['twilio_sms_settings'] ?? 'Twilio SMS Settings'); ?></span>
                        </div>
                        <hr>
                        <div class="col-md-4">
                            <label
                                class="form-label"><?php echo e($lang->data['account_sid'] ?? 'Account SID'); ?><span
                                    class="text-danger">*</span></label>
                            <input type="text" required autofocus class="form-control"
                                wire:model="accountsid">
                                <?php $__errorArgs = ['accountsid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-4">
                            <label
                                class="form-label"><?php echo e($lang->data['auth_token'] ?? 'Auth Token'); ?><span
                                    class="text-danger">*</span></label>
                            <input type="text" required autofocus class="form-control"
                                wire:model="auth_token">
                                <?php $__errorArgs = ['auth_token'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-4">
                            <label
                                class="form-label"><?php echo e($lang->data['twilio_number'] ?? 'Twilio Number'); ?><span
                                    class="text-danger">*</span></label>
                            <input type="text" required autofocus class="form-control"
                                wire:model="twilio_number">
                                <?php $__errorArgs = ['twilio_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-12">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" id="employee" checked
                                    wire:model="enabled">
                                <label class="form-check-label"
                                    for="employee"><?php echo e($lang->data['sms_enabled'] ?? 'SMS Enabled'); ?></label>
                            </div>
                        </div>
                        <div class="mt-5"><span
                            class="text-sm text-uppercase "><?php echo e($lang->data['SMS Format'] ?? 'SMS Format'); ?></span>
                        </div>
                        <hr>
                        <div class="row mt-2 mb-2" >
                            <div class="col-12 col-md-12 col-lg-8 col-sm-12">
                                <label for=""><?php echo e($lang->data['create_order']??'Create Order'); ?></label>
                                <textarea name="text" class="form-control" id="" cols="30" x-ref="create" rows="12" x-model="myCreateSMS"> </textarea>
                            </div>
                            <div class="mt-4 col-12 col-lg-4 col-md-12">
                                <div class="row">
                                    <template x-for="(replace,index) in replacers">
                                        <div class="col-12 col-lg-6 col-md-12 mt-2">
                                            <button class="btn-sm btn btn-secondary w-100 h-100 "  x-text="replace" type="button" @click="addText(index,1)"></button>
                                        </div>
                                    </template>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="row mt-2">
                            <div class="col-12 col-md-12 col-lg-8 col-sm-12">
                                <label for=""><?php echo e($lang->data['status_change']??'Status Change'); ?></label>
                                <textarea name="text" class="form-control" id="" cols="30" x-ref="status" rows="12" x-model="myStatusChange"> </textarea>
                            </div>
                            <div class="mt-4 col-12 col-lg-4 col-md-12">
                                <div class="row">
                                    <template x-for="(replace,index) in replacers">
                                        <div class="col-12 col-lg-6 col-md-12 mt-2">
                                            <button class="btn-sm btn btn-secondary w-100 h-100 " x-text="replace" type="button" @click="addText(index,2)"></button>
                                        </div>
                                    </template>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex align-items-center justify-content-end">
                            <div>
                                <button type="submit" class="btn btn-primary ms-4"
                                    wire:click.prevent="save()"><?php echo e($lang->data['save'] ?? 'Save'); ?></button>
                            </div>
                        </div>
                    </form>
                    
                </div>
            </div>
        </div>
    </div>
    <?php $__env->startPush('js'); ?>
    <script>
        function initz()
        {

            return {
                replacers : <?php if ((object) ('replacer') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('replacer'->value()); ?>')<?php echo e('replacer'->hasModifier('defer') ? '.defer' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('replacer'); ?>')<?php endif; ?>,
                myCreateSMS : '',
                myStatusChange : '',
                start()
                {
                    let myloadData = <?php
    if (is_object(trim( preg_replace( '/\s+/', ' ', $create_order ) )) || is_array(trim( preg_replace( '/\s+/', ' ', $create_order ) ))) {
        echo "JSON.parse(atob('".base64_encode(json_encode(trim( preg_replace( '/\s+/', ' ', $create_order ) )))."'))";
    } elseif (is_string(trim( preg_replace( '/\s+/', ' ', $create_order ) ))) {
        echo "'".str_replace("'", "\'", trim( preg_replace( '/\s+/', ' ', $create_order ) ))."'";
    } else {
        echo json_encode(trim( preg_replace( '/\s+/', ' ', $create_order ) ));
    }
?>;
                    let smyloadData = <?php
    if (is_object(trim( preg_replace( '/\s+/', ' ', $status_change ) )) || is_array(trim( preg_replace( '/\s+/', ' ', $status_change ) ))) {
        echo "JSON.parse(atob('".base64_encode(json_encode(trim( preg_replace( '/\s+/', ' ', $status_change ) )))."'))";
    } elseif (is_string(trim( preg_replace( '/\s+/', ' ', $status_change ) ))) {
        echo "'".str_replace("'", "\'", trim( preg_replace( '/\s+/', ' ', $status_change ) ))."'";
    } else {
        echo json_encode(trim( preg_replace( '/\s+/', ' ', $status_change ) ));
    }
?>;
                    this.myCreateSMS = myloadData;
                    this.myStatusChange = smyloadData;
                    this.$watch('myCreateSMS', value => window.livewire.find('<?php echo e($_instance->id); ?>').create_order = value);
                    this.$watch('myStatusChange', value => window.livewire.find('<?php echo e($_instance->id); ?>').status_change = value);
                },
                addText(replace,index)
                {

                    if(index == 1)
                    {
                        var cursorPos = this.$refs.create.selectionStart;
                        v = this.myCreateSMS;
                        var textBefore = v.substring(0,  cursorPos);
                        var textAfter  = v.substring(cursorPos, v.length);
                        this.myCreateSMS = textBefore + replace + textAfter;
                        this.$refs.create.focus()
                    }
                    if(index == 2)
                    {
                        var cursorPos = this.$refs.status.selectionStart;
                        v = this.myStatusChange;
                        var textBefore = v.substring(0,  cursorPos);
                        var textAfter  = v.substring(cursorPos, v.length);
                        this.myStatusChange = textBefore + replace + textAfter;
                        this.$refs.status.focus()
                    }
                    window.livewire.find('<?php echo e($_instance->id); ?>').addTextToItem(replace,index)
                },
            }

        }
    </script>
    <?php $__env->stopPush(); ?>
   
</div><?php /**PATH C:\wamp64\www\Xfortech\Laundry-web\resources\views/livewire/admin/settings/s-m-s-settings.blade.php ENDPATH**/ ?>