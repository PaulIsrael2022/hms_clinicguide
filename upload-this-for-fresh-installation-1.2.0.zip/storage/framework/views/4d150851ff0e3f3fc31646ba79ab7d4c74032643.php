<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Laundry Box - Installer</title>
    <link rel="shortcut icon" href="<?php echo e(asset('uploads/favicon/favicon.png')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('assets/install/font-awesome/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/install/css/backend-plugin.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/install/css/backende209.css?v=1.0.0')); ?>">
</head>
<body class=" ">
<?php echo $__env->yieldContent('install_content'); ?>
</body>
</html><?php /**PATH C:\wamp64\www\Xfortech\Laundry-web\resources\views/install/layout/app.blade.php ENDPATH**/ ?>