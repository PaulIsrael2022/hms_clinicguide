<!DOCTYPE html>
<html lang="en" <?php if(isRTL() == true): ?> dir="rtl" <?php endif; ?>>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" type="image/png" href="<?php echo e(asset(getFavIcon())); ?>">
    <title>
        <?php echo e(getApplicationName()); ?>

    </title>
    <link href="<?php echo e(asset('assets/css/poppinsfont.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/nucleo-icons.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/nucleo-svg.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/vendors/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link id="pagestyle" href="<?php echo e(asset('assets/css/argon-dashboard.min28b5.css?v=2.0.0')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/js/plugins/toastr.min.css')); ?>" rel="stylesheet" />
    <script src="<?php echo e(asset('assets/js/plugins/chartjs.min.js')); ?>"></script>
    <?php echo \Livewire\Livewire::scripts(); ?>

    <?php echo \Livewire\Livewire::styles(); ?>

    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <?php echo $__env->make('livewire.admin.translations.languageStyles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body class="g-sidenav-show <?php if(isRTL() == true): ?> rtl <?php endif; ?>">
    <div class="min-height-300 bg-primary position-absolute w-100"></div>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.side-bar')->html();
} elseif ($_instance->childHasBeenRendered('2neI4zj')) {
    $componentId = $_instance->getRenderedChildComponentId('2neI4zj');
    $componentTag = $_instance->getRenderedChildComponentTagName('2neI4zj');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('2neI4zj');
} else {
    $response = \Livewire\Livewire::mount('components.side-bar');
    $html = $response->html();
    $_instance->logRenderedChild('2neI4zj', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <main class="main-content position-relative border-radius-lg ">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.header')->html();
} elseif ($_instance->childHasBeenRendered('Y1UbtAR')) {
    $componentId = $_instance->getRenderedChildComponentId('Y1UbtAR');
    $componentTag = $_instance->getRenderedChildComponentTagName('Y1UbtAR');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Y1UbtAR');
} else {
    $response = \Livewire\Livewire::mount('components.header');
    $html = $response->html();
    $_instance->logRenderedChild('Y1UbtAR', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <div class="container-fluid py-2">
    <?php echo e($slot); ?>

    </div>
    </main>
    <script src="<?php echo e(asset('assets/js/jquery-3.6.0.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/core/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/core/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/perfect-scrollbar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/smooth-scrollbar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/toastr.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/dragula/dragula.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/argon-dashboard.min.js')); ?>"></script>
    <script>
        "use strict";
        var win = navigator.platform.indexOf('Win') > -1;
        if (win && document.querySelector('#sidenav-scrollbar')) {
            var options = {
                damping: '0.5'
            }
            Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
        }
    </script>
    <script>
    "use strict"
     Livewire.on('closemodal',() => {
        $('.modal').modal('hide');
        $('.modal-backdrop').remove();
        $('body').removeClass('modal-open');
        $('body').removeAttr('style');
        })
    </script>
    <script>
        "use strict";
        Livewire.on('reloadpage',() => {
        window.location.reload();
        })
    </script>
    <script>
        "use strict";
        window.addEventListener('alert', event => { 
            toastr[event.detail.type](event.detail.message, event.detail.title ?? '');
            toastr.options = {
                "closeButton": true,
                "progressBar": true,
            }
        });
        <?php if(Session::has('message')): ?>
        toastr.info("<?php echo e(Session::get('message')); ?>");
        <?php endif; ?>
    </script>
    <script>
        "use strict";
        var win = navigator.platform.indexOf('Win') > -1;
        if (win && document.querySelector('#sidenav-scrollbar')) {
            var options = {
                damping: '0.5'
            }
            Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
        }
    </script>
<?php echo $__env->yieldPushContent('js'); ?>
</body>
</html><?php /**PATH C:\wamp64\www\Xfortech\Laundry-web\resources\views/layouts/app.blade.php ENDPATH**/ ?>