<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="icon" type="image/png" href="<?php echo e(getFavIcon()); ?>">
        <title>
            <?php echo e(getApplicationName()); ?>

        </title>
        <link href="<?php echo e(asset('assets/css/poppinsfont.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('assets/css/nucleo-icons.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('assets/css/nucleo-svg.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('assets/vendors/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/css/nucleo-svg.css')); ?>" rel="stylesheet" />
        <link id="pagestyle" href="<?php echo e(asset('assets/css/argon-dashboard.min28b5.css?v=2.0.0')); ?>" rel="stylesheet" />
        <link id="pagestyle" href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet" />
        <?php echo \Livewire\Livewire::scripts(); ?>

        <?php echo \Livewire\Livewire::styles(); ?>

        <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
</head>
<body class="g-sidenav-show">
    <?php echo $__env->yieldContent('content'); ?>
    <script src="<?php echo e(asset('assets/js/core/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/core/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/perfect-scrollbar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/smooth-scrollbar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/dragula/dragula.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/jkanban/jkanban.js')); ?>"></script>
    <script>
        "use strict";
        var win = navigator.platform.indexOf('Win') > -1;
        if (win && document.querySelector('#sidenav-scrollbar')) {
            var options = {
                damping: '0.5'
            }
            Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
        }
    </script>
    <script src="<?php echo e(asset('assets/js/argon-dashboard.min.js')); ?>"></script>
</body>
</html><?php /**PATH C:\wamp64\www\Xfortech\Laundry-web\resources\views/layouts/login_layout.blade.php ENDPATH**/ ?>