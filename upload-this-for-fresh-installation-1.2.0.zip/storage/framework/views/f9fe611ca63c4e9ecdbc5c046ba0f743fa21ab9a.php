<div>
    <div class="row align-items-center justify-content-between mb-4">
        <div class="col">
            <h5 class="fw-500 text-white"><?php echo e($lang->data['add_service'] ?? 'Add Service'); ?></h5>
        </div>
        <div class="col-auto">
            <a href="<?php echo e(route('admin.service_list')); ?>" class="btn btn-icon btn-3 btn-white text-primary mb-0">
                <i class="fa fa-arrow-left me-2"></i> <?php echo e($lang->data['back'] ?? 'Back'); ?>

            </a>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <form>
                    <div class="card-body p-3 mb-1 mt-2">
                        <div class="row g-3 align-items-center">
                            <div class="col-md-6">
                                <label
                                    class="form-label"><?php echo e($lang->data['service_name'] ?? 'Service Name'); ?></label>
                                <input type="text" required class="form-control"
                                    placeholder="<?php echo e($lang->data['enter_service_name'] ?? 'Enter Service Name'); ?>"
                                    wire:model="service_name">
                                <?php $__errorArgs = ['service_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-3">
                                <button type="button" class="btn btn-primary mt-5" data-bs-toggle="modal"
                                    data-bs-target="#exampleModal">
                                    <?php echo e($lang->data['select_icon'] ?? 'Select Icon'); ?>

                                </button>
                                <?php $__errorArgs = ['icon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-3 text-center ">
                                <div class="avatar avatar-xl">
                                    <?php if($imageicon): ?>
                                        <img src="<?php echo e(asset('assets/img/service-icons/' . $imageicon['path'])); ?>"
                                            class="rounded bg-light p-2">
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table align-items-center mb-0">
                                <thead class="bg-light">
                                    <tr>
                                        <th class="text-uppercase text-secondary text-xs opacity-7">#</th>
                                        <th class="text-uppercase text-secondary text-xs opacity-7 ps-3">
                                            <?php echo e($lang->data['service_type'] ?? 'Service Type'); ?></th>
                                        <th class="text-uppercase text-secondary text-xs opacity-7 ps-3">
                                            <?php echo e($lang->data['service_price'] ?? 'Service Price'); ?></th>
                                        <th class="text-secondary opacity-7"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $inputs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <p class="text-sm px-3 mb-0"><?php echo e($loop->index + 1); ?></p>
                                            </td>
                                            <td>
                                                <select class="form-select"
                                                    wire:model="servicetypes.<?php echo e($value); ?>">
                                                    <option value="">
                                                        <?php echo e($lang->data['select_service_type'] ?? 'Select A Service Type'); ?>

                                                    </option>
                                                    <?php $__currentLoopData = $service_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($item->id); ?>">
                                                            <?php echo e($item->service_type_name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php $__errorArgs = ['servicetypes.' . $value];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </td>
                                            <td class="align-middle text-center">
                                                <input type="text" class="form-control" placeholder="" value="100"
                                                    style="width: 150px;" wire:model="prices.<?php echo e($value); ?>">
                                                <?php $__errorArgs = ['prices.' . $value];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </td>
                                            <td class="align-middle">
                                                <a href="#" class="text-danger fw-600"
                                                    wire:click.prevent="remove(<?php echo e($key); ?>,<?php echo e($value); ?>)">
                                                    <i class="fa fa-times"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <div class="footer-button px-5">
                                <a href="#" wire:click="add(<?php echo e($inputi); ?>)"
                                    class="badge badge-xs badge-success fw-600 text-xs">
                                    <?php echo e($lang->data['add_service_type'] ?? 'Add Service Type'); ?>

                                </a>
                            </div>
                        </div>
                    </div>
                    <?php $__errorArgs = ['inputerror'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger mx-3"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <hr>
                    <div class="card-footer p-2 mx-2">
                        <div class="d-flex align-items-center justify-content-between">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" id="employee" checked
                                    wire:model="is_active">
                                <label class="form-check-label"
                                    for="employee"><?php echo e($lang->data['is_active'] ?? 'Is Active'); ?> ?</label>
                            </div>
                            <div>
                                <a href="<?php echo e(route('admin.service_list')); ?>"> <button type="button"
                                        class="btn btn-secondary"><?php echo e($lang->data['cancel'] ?? 'Cancel'); ?></button></a>
                                <button type="submit" class="btn btn-primary ms-4"
                                    wire:click.prevent="save"><?php echo e($lang->data['submit'] ?? 'Submit'); ?></button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true"
        wire:ignore.self>
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"><?php echo e($lang->data['select_icon'] ?? 'Select Icon'); ?>

                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" x-data="">
                    <div class="row">
                        <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-1 customwidth m-2 customhover1" wire:click="selectIcon(<?php echo e($key); ?>)">
                                <img src="<?php echo e(asset('assets/img/service-icons/' . $value['path'])); ?>"
                                    class="img-fluid">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary"
                        data-bs-dismiss="modal"><?php echo e($lang->data['close'] ?? 'Close'); ?></button>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\wamp64\www\Xfortech\Laundry-web\resources\views/livewire/admin/service/service-create.blade.php ENDPATH**/ ?>