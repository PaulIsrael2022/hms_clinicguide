<style>
<?php if(isRTL() == true): ?>
    .form-check{
        display:inline-block;
    }
    .btn > i{
        margin-left : 10px;
    }
    .form-select {
        text-align: left;
    }
<?php endif; ?>
</style><?php /**PATH C:\wamp64\www\Xfortech\Laundry-web\resources\views/livewire/admin/translations/languageStyles.blade.php ENDPATH**/ ?>