@livewireScripts
@livewireStyles
@yield('content')