<style>
@if (isRTL() == true)
    .form-check{
        display:inline-block;
    }
    .btn > i{
        margin-left : 10px;
    }
    .form-select {
        text-align: left;
    }
@endif
</style>