<?php
namespace App\Http\Livewire;
use Livewire\Component;
class IndexPage extends Component
{
    /* render the page*/
    public function render()
    {
        return view('livewire.index-page');
    }
}